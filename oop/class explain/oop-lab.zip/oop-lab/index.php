<?php
  require_once('Contact.php');
  require_once('SpecialContact.php');

  $con = new Contact();
  $con->setName("Mohammed");
  $con->setEmail("m@gmail.com");

  echo $con->getName();
  echo "</br>";
  echo $con->getEmail();

  $data['id'] = 15;
  $data['name'] = "Ahmet";
  $data['email'] = "ahmed@gmail.com";

  $con2 = new Contact($data);
  echo "</br>";
  echo $con2->getName();
  echo "</br>";
  echo $con2->getEmail();

  $con3 = new SpecialContact($data);
  $con3->setFacebookHandle('@m_saudi');

  echo "</br>";
  echo $con3->getId();
  echo "</br>";
  echo $con3->getName();
  echo "</br>";
  echo $con3->getEmail();
  echo "</br>";
  echo $con3->getFacebookHandle();

  //BE CAREFUL

  echo "</br>". $con3->twitterHandle;

  $con3->twitterHandle = "@msaudi_t";
  echo "</br>". $con3->twitterHandle;



 ?>
