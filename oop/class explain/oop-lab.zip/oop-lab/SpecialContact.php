<?php
require_once('Contact.php');

class SpecialContact extends Contact
{
  private $facebook_handle;

  public function getFacebookHandle()
  {
    return $this->facebook_handle;
  }

  public function setFacebookHandle($value='')
  {
    $this->facebook_handle = $value;
  }
}

?>
