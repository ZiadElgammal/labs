<?php
  require_once 'database_credentials.php';
  require_once 'database_functions.php';

  $db = db_connect();
  $result_set = $db->query("SELECT * FROM contacts");

  foreach ($result_set  as $contact) {
    echo $contact['name']."--".$contact['email']."</br>";
  }

  //print_r($result_set);
 ?>
