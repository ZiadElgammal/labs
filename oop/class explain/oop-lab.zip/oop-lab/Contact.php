<?php
class Contact
{
  private $id;
  private $name;
  private $email;

  public function __construct($args = null){
    if($args !== null){
      $this->id = $args['id'];
      $this->name = $args['name'];
      $this->email = $args['email'];
    }
  }

  public function getId(){
    return $this->id;
  }

  public function setId($value){
    $this->id = $value;
  }

  public function getName(){
    return $this->name;
  }

  public function setName($value){
    $this->name = $value;
  }
  public function getEmail(){
    return $this->email;
  }

  public function setEmail($value){
    $this->email = $value;
  }
}

?>
