<?php

include_once('../private/header.php');

 ?>

	<div class="expanding-wrapper">
		<img class="expanding-wrapper-img" src="img/bg.jpeg" alt="">
	</div>
	<footer>

	</footer>


</body>
</html>
