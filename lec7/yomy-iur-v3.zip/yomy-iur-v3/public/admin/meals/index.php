<?php
require_once '../../../private/initialize.php';
require_once PRIVATE_PATH.'/admin_header.php';

echo "Meals admin";

 ?>
