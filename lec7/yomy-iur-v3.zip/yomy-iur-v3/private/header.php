<!doctype html>
<html lang="en">
<head>
	<title>YomyShop - Istanbul</title>
	<meta charset="utf-8">
	<link rel="stylesheet" media="all" href="css/public.css">
</head>

<body>
	<header>
		<h1>
      <a href="index.php">
        <img class="yomy-icon" src= "img/yomy-icon.png" /> </br></br>
        YomyShop
      </a>
		</h1>
	</header>

	<div id="main">
		<ul id="menu">
			<li><a href="meals.php">View Meals</a></li>
			<li><a href="aboutus.php">About Us</a></li>
		</ul>

	</div>
