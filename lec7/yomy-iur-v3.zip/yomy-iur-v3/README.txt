2- CRUD category - Active Record Pattern
>> Class, Constructors , Create() method to save to db
>> Test from outside using sql

>> find_all() method to save to db
>> Test from outside using sql


>> find_by_id() method to save to db
>> Test from outside using sql

>>edit()

>>delete()
